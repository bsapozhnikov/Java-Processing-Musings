import urllib2
print "OK"
exit()

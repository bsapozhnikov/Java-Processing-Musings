font = loadFont("data/Cabal1-48.vlw")
def setup():
    size(10, 10, P3D)
    noLoop()
    print 'OK'
    exit()
